$ (document) .ready (function () {
	wow = new WOW (
      {
        animateClass: 'animated',
        offset: 100,
        callback: function (box) {
          console.log ("WOW: animating <" + box.tagName.toLowerCase () + ">")
        }
      }
    );
    wow.init ();
    
	var percent = [1.1,1.3,1.8,2.6];
	var minMoney = [10,100,500,1000];
	var maxMoney = [100,500,1000,50000];
	$ ("# amount"). val (minMoney [0]);

	
	// Calculator
	function calc () {
		amount = parseFloat ($ ("# amount"). val ());

		id = -1;
		var length = percent.length;
		var i = 0;
		while (length)
			if (minMoney [i] <= amount && amount <= maxMoney [i]) {
				id = i;
				break;
			}
			++;
		}
		
		if (id! = -1) {

			profitHourly = amount / 100 * percent [id];
			profitHourly = profitHourly.toFixed (2);
			profitDaily = amount / 100 * percent [id];
			profitDaily = profitDaily.toFixed (2);
			profitPercent = percent [id];
			profitPercent = profitPercent.toFixed (0);
			profitPower = amount / 0.10;
			profitPower = profitPower.toFixed (0);
			profitWeekly = profitDaily * 10;
			profitWeekly = profitWeekly.toFixed (2);
			profitMonthly = profitWeekly * 4;
			profitMonthly = profitMonthly.toFixed (2);


			if (amount <minMoney [id] || isNaN (amount) == true)
				$ ("# profitHourly"). text ("Error!");
				$ ("# profitDaily"). text ("Error!");
				$ ("# profitWeekly"). text ("Error!");
				$ ("# profitMonthly"). text ("Error!");
				$ ("# profitPower"). text ("Error!");
				$ ("# profitPercent"). text ("Error!");
			} else {
				$ ("# profitHourly"). text ("$" + profitHourly);
				$ ("# profitDaily"). text ("$" + profitDaily);
				$ ("# profitWeekly"). text ("$" + profitWeekly);
				$ ("# profitMonthly"). text ("$" + profitMonthly);
				$ ("# profitPower"). text (profitPower + "Gh / s");
				$ ("# profitPercent"). text (profitPercent + "%");
			}
		} else {
			$ ("# profitHourly"). text ("Error!");
			$ ("# profitDaily"). text ("Error!");
			$ ("# profitWeekly"). text ("Error!");
			$ ("# profitMonthly"). text ("Error!");
			$ ("# profitPower"). text ("Error!");
		}
	}
	if ($ ("# amount"). length) {
		calc ();
	}
	$ ("# amount"). keyup (function () {
		calc ();
	});

	
});